<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="simple.css" rel="stylesheet" type="text/css">
<form name="form" method="post" action="register_finish.php">
<div id="lg">
<div id="lgtitle">
申請帳號
</div>
<div id="regput">
暱稱：<input type="text" name="na" /> <br>
帳號：<input type="text" name="id" /> <br>
密碼：<input type="password" name="pwd" /> <br>
確認密碼：<input type="password" name="pwd2" /> <br>
信箱：<input type="text" name="email" /> <br>
<input type="submit" name="button" value="確定" />
</div>
<div id="reg">
<a href="index.php">回登入</a>
</div>
</div>
</form>
