<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="simple.css" rel="stylesheet" type="text/css">
<?php
$db_server = "localhost";
$db_name = "third";

$db_user = "root";

$db_passwd = "";

if(!@mysql_connect($db_server, $db_user, $db_passwd))
        die("無法對資料庫連線");

mysql_query("SET NAMES utf8");

if(!@mysql_select_db($db_name))
        die("無法使用資料庫");
?> 

